# SEIM

SEIM (`seim-core`) is a self-evolving application runtime and repository engineering control plane for an existing Node.js and React/Next.js web application.

Its intended operating model is: a developer builds and hands off a sound baseline application; SEIM then observes it, turns supported product signals or goals into bounded changes, verifies those changes, opens GitHub pull requests, and connects verified commits to Vercel or AWS ECS delivery workflows.

This is a working foundation, not a promise of fully unattended development for arbitrary software. Supported flows are tested; sensitive and unsupported work is blocked or left as explicit review work.

See [architecture.md](./architecture.md) for all runtime, handoff, planning, verification, GitHub, feedback, persistence, security, Vercel, and AWS flows.

## Verified status

Verified locally on 2026-08-30:

| Check | Result |
|---|---|
| TypeScript build | Passed |
| Jest | 43 suites passed |
| Tests | 218 passed |
| Package dry run | Passed |
| Runtime version restart/rollback regression tests | Passed |

External service credentials were not used during this verification. Real Redis, GitHub, Vercel, AWS, and Postgres deployment drills remain operator acceptance tests.

## What is implemented

- Express request observation, metrics, behavior tracking, dynamic route handling, candidate evaluation, deterministic canaries, and rollback controls.
- Fastify and generic adapter integration for observation; live evolved-handler replacement is not equivalent to Express in the current release.
- Issue detection for repeated missing routes, 5xx patterns, and selected UX signals with basic scanner/noise filtering.
- React, Vite, Next App Router, Next Pages Router, and React Router context detection and bounded page/component planning.
- `.seim/handoff.json` as the developer-approved takeover contract.
- Repository context indexing for source, tests, API contracts, databases, design systems, documentation, workspaces, and deployment files.
- Goal decomposition into dependency-aware frontend, backend, review, and test tasks.
- Disposable-workspace verification with root confinement, static security checks, typecheck, tests, integration tests, build, and browser checks when configured.
- Risk-based stop, approval, pull-request, merge, and deploy boundaries.
- Atomic GitHub publication using one tree and one commit, stale-source hash checks, pull requests, and protected auto-merge requests.
- GitHub token or short-lived GitHub App installation authentication.
- Signed GitHub workflow/deployment feedback, deduplication, bounded retry, repair PRs, and a recurring-failure circuit breaker.
- Generated GitHub Actions for verification, Vercel preview/production/rollback, and AWS OIDC/ECR/ECS deployment/rollback.
- Truthful runtime storage modes: in-memory, single-writer file persistence, and Redis endpoint-version persistence.

## Support boundaries

| Area | Current support |
|---|---|
| Express backend | Runtime observation and dynamic evolved routes |
| Fastify/generic HTTP | Integration and observation; no equivalent universal live route swap |
| React/Vite | Context-aware component/page and route planning |
| Next.js | App Router and Pages Router file planning |
| Repository changes | Supported frontend/backend planners plus bounded AI CI repair |
| Auth, billing, secrets, migrations | Protected or approval-gated; no general autonomous planner |
| GitHub | PR publication, merge controls, App auth, signed delivery feedback |
| Vercel | Generated GitHub Actions for preview, production, health, rollback |
| AWS | Generated GitHub Actions using OIDC, ECR, ECS, health, rollback |
| Multi-replica state | Redis for endpoint versions only; other runtime stores are not centralized |

## Install

```bash
npm install seim-core
```

Node.js 18 or newer is required. Install optional integrations separately when used:

```bash
npm install redis isolated-vm
```

The package does not bundle a Postgres driver. Supply a Postgres-compatible query client through configuration.

## Express runtime integration

```js
const express = require('express');
const { seim } = require('seim-core');

const app = express();
const s = seim({
  mode: 'restrict',
  environment: 'development',
  framework: 'express',
  storage: { type: 'memory' },
  auth: {
    enabled: true,
    secret: process.env.SEIM_AUTH_SECRET,
  },
  behavior: {
    enabled: true,
    autoScaffold: false,
    minPatternFrequency: 3,
  },
});

app.use(express.json());
app.use(s.listener());
app.use(s.config.studioPath, s.dashboard);

app.get('/api/health', (_req, res) => res.json({ ok: true }));

const server = app.listen(3000);

async function stop() {
  await s.shutdown();
  server.close();
}
process.on('SIGTERM', stop);
process.on('SIGINT', stop);
```

Start with `mode: 'restrict'`, no autonomous promotion, and memory storage during evaluation. Enable broader behavior only after project rules, tests, storage, Studio authentication, and rollback behavior are established.

## Storage

```ts
seim({ storage: { type: 'memory' } });
seim({ storage: { type: 'file' }, storagePath: '/durable/seim' });
seim({ storage: { type: 'redis', connection: process.env.REDIS_URL } });
```

- `memory` is process-local and writes no runtime version files. Production configuration rejects it.
- `file` atomically persists endpoint versions and is intended for one writer on durable local storage.
- `redis` uses hashes, sorted sets, active-version keys, and a route registry for restart-safe endpoint version state. Install `redis` separately.

Redis does not currently centralize runtime metrics, candidate/artifact stores, learned patterns, or the changelog. Those limitations matter in multi-replica deployments; see the persistence section in [architecture.md](./architecture.md).

## Hand off an existing application

From the application repository:

```bash
npx seim handoff .
```

Review the generated `.seim/handoff.json`. The default contract uses `pull_request` autonomy and protects `.env`, `.git`, and secret paths. Configure:

- frontend, backend, tests, design-system, and database ownership paths;
- typecheck, test, integration, build, and browser commands;
- protected and approval-required paths;
- autonomy: `observe`, `plan`, `pull_request`, `merge`, or `deploy`;
- Vercel or AWS ECS delivery targets.

The application can then be registered and given a goal:

```ts
const s = seim({
  mode: 'restrict',
  storage: { type: 'file' },
  engineer: {
    enabled: true,
    rootDir: process.cwd(),
    repository: 'github',
    persistence: 'file',
    github: {
      owner: 'acme',
      repository: 'storefront',
      token: process.env.SEIM_GITHUB_TOKEN,
    },
  },
});

const application = await s.engineer.handoffApplication(process.cwd());
const plan = await s.engineer.submitGoal({
  applicationId: application.id,
  title: 'Add a cart dashboard',
  description: 'Build /cart in the existing React app and GET /api/cart in the backend.',
  acceptanceCriteria: [
    'Users can see cart items',
    'The API returns only the current user cart',
    'Existing tests remain green',
  ],
});

await s.engineer.runPlan(plan.id);
```

Executable supported tasks proceed through policy and verification. Sensitive review tasks, unsupported tasks, and acceptance-test work remain visible until completed or approved through the control plane.

## GitHub authentication

Use either a scoped token or a GitHub App. GitHub App mode avoids a long-lived personal token:

```ts
engineer: {
  repository: 'github',
  github: {
    owner: 'acme',
    repository: 'storefront',
    app: {
      appId: process.env.SEIM_GITHUB_APP_ID,
      installationId: process.env.SEIM_GITHUB_INSTALLATION_ID,
      privateKey: process.env.SEIM_GITHUB_PRIVATE_KEY,
    },
  },
}
```

Use least-privilege GitHub permissions, branch protection, required checks, CODEOWNERS, and protected environments. `merge` or `deploy` autonomy only requests actions allowed by those external policies.

## Vercel and AWS ECS delivery

Generate workflows from the reviewed handoff:

```bash
npx seim delivery . --vercel --aws
```

This creates a reusable verification workflow plus provider deployment and manual rollback workflows.

For Vercel, configure:

- secret `VERCEL_TOKEN`;
- variables `VERCEL_ORG_ID` and `VERCEL_PROJECT_ID`.

For AWS ECS, configure:

- variables `AWS_ROLE_ARN`, `AWS_REGION`, `AWS_ECR_REPOSITORY`, `AWS_ECS_CLUSTER`, and `AWS_ECS_SERVICE`;
- optional variable `AWS_HEALTHCHECK_URL`;
- a checked-in task definition and the correct application container name in the handoff target.

AWS authentication uses GitHub OIDC. Do not create long-lived AWS access-key secrets for these workflows. Configure required reviewers and branch restrictions on the GitHub `production` environment.

## GitHub delivery feedback

Enable feedback only with a GitHub repository provider, repository authentication, and a webhook secret:

```ts
engineer: {
  enabled: true,
  repository: 'github',
  persistence: 'postgres',
  postgres: { client: pool },
  github: { owner: 'acme', repository: 'storefront', token: process.env.SEIM_GITHUB_TOKEN },
  feedback: {
    enabled: true,
    webhookSecret: process.env.SEIM_GITHUB_WEBHOOK_SECRET,
    allowedBranches: ['main'],
    allowedWorkflowPrefixes: ['SEIM'],
    maxTransientRetries: 1,
    maxRepairsPerFingerprint: 2,
  },
}
```

Mount `s.githubWebhook` with `express.raw({ type: 'application/json', limit: '1mb' })` before JSON parsing. Signature verification requires the exact raw request bytes. Subscribe the GitHub webhook to `workflow_run` and `deployment_status` events.

## CLI

```bash
npx seim init
npx seim handoff .
npx seim delivery . --vercel --aws
npx seim status http://localhost:3000
npx seim analyze ./routes/users.js
npx seim benchmark http://localhost:3000/api/health
npx seim rollback /api/users
npx seim apply .
```

## Safety model

SEIM uses several independent gates:

- developer-approved handoff policy and autonomy;
- project-root confinement and path normalization;
- protected and approval-required paths;
- sensitive-code and critical-change rejection;
- expected source hashes to reject stale updates;
- disposable verification workspace and scrubbed secret-like environment variables;
- configured project checks and required browser testing for frontend changes;
- pull requests, branch protection, required reviews, and protected deployment environments;
- signed and deduplicated GitHub webhooks with allowlists and a failure circuit breaker;
- deterministic canary assignment and runtime rollback controls.

The built-in workspace and JavaScript sandbox are not OS isolation boundaries. Run repository verification in a dedicated least-privilege container or VM before allowing it to process untrusted repositories or commands.

JavaScript project configuration is not executed during discovery by default. Trusted local projects may opt in with `SEIM_ALLOW_JS_CONFIG=true`. Engineer verification rejects symbolic links, and browser-based Studio mutations must be same-origin.

## What SEIM does not yet guarantee

- fully autonomous development of arbitrary requirements;
- safe unsupervised auth, authorization, payment, billing, secret, or migration changes;
- central multi-replica persistence for all runtime state;
- identical runtime hot swapping across Express, Fastify, and generic HTTP;
- production correctness without application-specific tests and acceptance criteria;
- cloud delivery without operator-owned GitHub, Vercel, AWS, IAM, and rollback configuration;
- hostile-code isolation inside the Node.js process.

These are the current engineering boundaries. The package is designed to stop or request review when it cannot establish a safe path.

## Development

```bash
npm run build
npm test -- --runInBand
npm pack --dry-run --json
```

The current baseline is 42 passing suites and 206 passing tests.

## License

MIT. See [LICENSE](./LICENSE).
